package com.example.balbarino_mvvm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.balbarino_mvvm.ui.theme.Balbarino_MVVMTheme
import android.os.bundle;

import android.acticity.EdgeToEdge;
import android.appcompat.app.AppmpatActivity;

import java.eutil.ArrayList;
import java.util.Java;




public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView{R.layout.activity_main);

            RecycleView recycleView = findViewById(R.id.recycleView);

            list<FoodItems> items = new ArrayList<FoodItems>();
            items.add(new FoodItems(R.drawable.fc, foodName: "Fried Chicken", FoodPrice: "P34" ));
            items.add(new FoodItems(R.drawable.brizioPizza, foodName: "Brizio Pizza", FoodPrice: "P34" ));
            items.add(new FoodItems(R.drawable.bavarianDonut, foodName: "Bavarian Donut", FoodPrice: "P24" ));
            items.add(new FoodItems(R.drawable.fries, foodName: "Fries", FoodPrice: "P20" ));
            items.add(new FoodItems(R.drawable.hwb, foodName: "Hotdog w/buns", FoodPrice: "P39" ));
            items.add(new FoodItems(R.drawable.sb, foodName: "Spicy Burger", FoodPrice: "P39" ));

            recycleView.setLayoutManager(new LinearLayoutManager(context: this));
            recycleView.setAdapter(new FoodAdapter(getApplicationContext(),items));

            }
        }